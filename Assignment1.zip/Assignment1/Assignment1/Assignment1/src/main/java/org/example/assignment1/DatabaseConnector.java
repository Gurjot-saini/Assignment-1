package org.example.assignment1;

import javafx.scene.chart.PieChart;

import java.sql.*;

public class DatabaseConnector {

    private static final String URL = "jdbc:mysql://localhost:3306/carsales";
    private static final String USER = "root";

   /*
    * create database carsales;
 use carsales;
 CREATE TABLE  carsales2020 (
    company_name VARCHAR(255),
    units_sold INT
);

INSERT INTO carsales2020 (company_name, units_sold) VALUES
('Maruti Suzuki', 150000),
('Hyundai', 120000),
('Tata Motors', 100000),
('Mahindra & Mahindra', 80000),
('Kia Motors', 70000),
('Toyota', 60000),
('Honda', 55000),
('Ford', 50000);*/

    private static final String PASS = "";

    public Connection connect() {
        try {
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            throw new RuntimeException("Error connecting to the database", e);
        }
    }

    public void fetchData(PieChart pieChart) {
        String query = "SELECT company_name, units_sold FROM carsales2020";
        try (Connection conn = connect();
             PreparedStatement statement = conn.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String companyName = resultSet.getString("company_name");
                double units = resultSet.getDouble("units_sold");
                pieChart.getData().add(new PieChart.Data(companyName, units));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
